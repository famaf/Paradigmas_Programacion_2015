object fuertevsdebil{

    def main(args: Array[String]) {
        val b : Double = 2
        var c : Int = types(b)
        println(c)
    }

    def types(a: Int) : Int = a + 3
}
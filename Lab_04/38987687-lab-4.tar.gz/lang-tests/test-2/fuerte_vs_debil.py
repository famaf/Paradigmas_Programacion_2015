def types(a):

    c = 'f'

    print (a+c)

types(2)
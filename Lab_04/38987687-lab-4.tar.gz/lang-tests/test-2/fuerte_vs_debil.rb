def fuerte_vs_debil(a)

    c = a + "hola"

    print c
end

fuerte_vs_debil(2)
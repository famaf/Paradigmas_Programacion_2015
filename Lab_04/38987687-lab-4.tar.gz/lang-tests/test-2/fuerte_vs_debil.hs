types::Int->Int
types a = let c = 'f' in
          a + c
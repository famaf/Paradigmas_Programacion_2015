class fuerte_vs_debil
{
    public static void main(String []args)
    {
        int a = 3.5;
        System.out.println(a);
    }
}

suma_rara x |  x == 0  = 1
            | otherwise = 10 + suma_rara(x - 1)

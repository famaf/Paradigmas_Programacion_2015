public class asignacion
{
    public static void main(String []args)
    {
        int a = 0;
        System.out.println("a vale: " + a);
        a = 5;
        System.out.println("ahora a vale: " + a);
    }
}
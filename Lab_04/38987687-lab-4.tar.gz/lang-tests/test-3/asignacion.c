#include <stdio.h>

int main(void) {
    int a = 50;
    printf("'a' ahora vale %i\n", a);
    a = 30;
    printf("'a' ahora vale %i\n", a);

    return 0;
}
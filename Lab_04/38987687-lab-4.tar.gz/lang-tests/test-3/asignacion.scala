object asignacion
{
    def main(args: Array[String])
    {
        var a = 10
        println(a)
        a = 20
        println(a)
    }
}
def asignacion()
    x = 1

    print "x vale #{x}"

    x = 2
    print "\nahora x vale #{x} \n"
end

asignacion()
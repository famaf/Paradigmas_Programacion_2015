asignacion :: Int->Int
asignacion x = let x = 1 in
               let x = x + 5 in
               x + 2
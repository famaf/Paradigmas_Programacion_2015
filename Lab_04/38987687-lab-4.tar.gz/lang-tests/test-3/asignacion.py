def asignacion():

    x = 1
    print "x vale " + str(x)
    x = 2
    print "ahora x vale " + str(x)

asignacion()
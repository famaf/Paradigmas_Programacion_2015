tipado x y = x + y

ejecutor = tipado "hola" 4
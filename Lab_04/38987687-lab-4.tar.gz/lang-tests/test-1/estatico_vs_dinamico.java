public class miPrimeraClase 
{
    public static void main(String []args)
    {
        System.out.println("Entre'\n");

        int var = 0;

        String palabra = "Esto es horrible";

        var = var + palabra;

        System.out.println("Sali\n");
    }
}

print "Entre"

a = 3
a = a + "casa"

print "Sali"
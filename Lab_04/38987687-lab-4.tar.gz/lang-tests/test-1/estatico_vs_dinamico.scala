object HolaMundo
{
    def main(args: Array[String])
    {
        println("Entre")
        var a = 10
        var b = "Soy un koala"
        var c = a ++ b
        println(c)
        println("Sali")
    }
}
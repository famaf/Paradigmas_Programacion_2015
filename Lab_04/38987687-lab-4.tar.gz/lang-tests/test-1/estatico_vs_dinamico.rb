puts "Entre"
a = 10
b = "Me llamo silla"
a = a + b
puts "Sali"
